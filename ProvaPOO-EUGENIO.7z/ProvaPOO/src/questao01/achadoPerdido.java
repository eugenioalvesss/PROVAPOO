package questao01;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class achadoPerdido extends publicacao {

	private String titulo;
	private String descricao;
	private String foto;
	private String tipo;
	private String localAchado;
	private String dataHora;
	private String status;

	
	
	 public void achadoPerdido(String titulo, String descricao, String tipo, String status) {
		
		this.titulo = titulo;
		this.descricao = descricao;
		this.tipo = tipo;
		this.status = status;
	}
	 
	    @Override
	    public String buscarTitulo (String Titulo) {
	    	return "T�tulo: " + getTitulo() +

}
	


