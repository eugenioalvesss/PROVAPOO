package questao01;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

interface class publicacao {
	
	  public abstract void buscarTitulo(String titulo){
	        JFrame jFrame = new JFrame();
	        jFrame.setVisible(true);
	        JOptionPane.showMessageDialog(jFrame,"PLACA: "+placa+"/n Ano"+ano);
	    }

}
