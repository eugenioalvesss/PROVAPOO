package questao02;

public class TrabalhoVoluntario extends Projeto {
	
	private String tipoTrabalho;
	private int duracaoTrabalho;
	
	public TrabalhoVoluntario(String tipoTrabalho, int duracaoTrabalho) {
		super();
		this.tipoTrabalho = tipoTrabalho;
		this.duracaoTrabalho = duracaoTrabalho;
	}

	public String getTipoTrabalho() {
		return tipoTrabalho;
	}

	public void setTipoTrabalho(String tipoTrabalho) {
		this.tipoTrabalho = tipoTrabalho;
	}

	public int getDuracaoTrabalho() {
		return duracaoTrabalho;
	}

	public void setDuracaoTrabalho(int duracaoTrabalho) {
		this.duracaoTrabalho = duracaoTrabalho;
	}
	
	    public boolean validaProjeto(String nomeProjeto) {
	        if (duracaoTrabalho>2) {
	            return true;
	        } else {
	  return false;
	        }
	    }

	    public String imprimeProjeto() {
	        return "Nome do Projeto: "+getNomeProjeto()+"Descricao: "+getDescricao()+"Data Inicio: "+getDataInicio()+"Data Fim: "+getDataFim()+"Tipo de Trabalho: "+getTipoTrabalho()+"Dura��o Trabalho: "
	    +getDuracaoTrabalho();
	    }
	}

	


