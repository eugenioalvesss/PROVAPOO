package questao02;

import java.util.Scanner;

public class ProjetoSocial {

	public static void main(String[] args) {
		int opcoes = 0;
		
		 Scanner ler = new Scanner(System.in);
		
        System.out.println("Escolha uma das op��es abaixo:");
        System.out.println("1 - Distribui��o de alimentos");
        System.out.println("2 - Trabalho Voluntario");
        System.out.println("3 - Sair");
        
        opcoes = ler.nextInt();
        switch (opcoes) {
            case 1:
            	System.out.println("DISTRIBUICAO DE ALIMENTOS");
            	DistribuicaoAlimento distribuicaoalimento = new DistribuicaoAlimento("Arroz",55);
               
                distribuicaoalimento = ler.imprimeProjeto();
                
                onibus.exibirDados();
                break;
            case 2:
                System.out.println("TRABALHO VOLUNTARIO");
                System.out.println("ESCREVA A QUANTIDADE DE EIXOS: ");
                eixos = ler.nextInt();
                Caminhao caminhao = new Caminhao(placa,ano,eixos);
                caminhao.exibirDados();
                break;
            case 3:
            	 break;
            default:
                System.out.println("Op��o inv�lida!");
	}

	}

}
