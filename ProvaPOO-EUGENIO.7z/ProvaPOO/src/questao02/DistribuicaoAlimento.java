package questao02;

public class DistribuicaoAlimento extends Projeto {

	private String descAlimento;
	private float qtde;
	
	 public DistribuicaoAlimento(String descAlimento, float qtde) {
		super();
		this.descAlimento = descAlimento;
		this.qtde = qtde;
	}

	 


	public String getDescAlimento() {
		return descAlimento;
	}




	public void setDescAlimento(String descAlimento) {
		this.descAlimento = descAlimento;
	}




	public float getQtde() {
		return qtde;
	}




	public void setQtde(float qtde) {
		this.qtde = qtde;
	}

	    public boolean validaProjeto(String nomeProjeto) {
	        if(getDataFim()==""){
	            return true;
	        }else
	        {
	            return false;
	        }
	    }

	    public String imprimeProjeto() {
	        return "Nome do Projeto: "+getNomeProjeto()+" Descricao: "+getDescricao()+" Data Inicio: "+getDataInicio()+ "Data Fim: "+getDataFim()+"Descricao Alimento: "+getDescAlimento()+"Qtde: "
	    +getQtde();
	    }
	}



